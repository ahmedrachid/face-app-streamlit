docker build -t faceapp .
docker un -p 8501:8501 faceapp 